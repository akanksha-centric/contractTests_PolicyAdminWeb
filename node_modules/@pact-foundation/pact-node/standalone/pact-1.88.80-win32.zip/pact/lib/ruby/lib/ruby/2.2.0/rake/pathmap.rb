# TODO: Remove in Rake 11

require 'rake/ext/string'
